### 1 черта  

1\. 一(いち) один  
![04e00.svg](./downloaded/04e00.svg)    
2\. 丨 (ぼう) жезл, прут  
![04e28.svg](./downloaded/04e28.svg)  
3\. 丶 (てん) точка  
![04e36.svg](./downloaded/04e36.svg)  
4\. 丿 (てん) НО-кана  
![04e3f.svg](./downloaded/04e3f.svg)  
5\. 乙 (おつ) рыбный крючок  
![04e59.svg](./downloaded/04e59.svg)  
6\. 亅 (はねぼう) шип, колючка, ус  
![04e85.svg](./downloaded/04e85.svg)  
### 2 черты  

7\. 二(に) два   
![04e8c.svg](./downloaded/04e8c.svg)  
8\. 亠 (なべぶた) крышка  
![04ea0.svg](./downloaded/04ea0.svg)  
9\. 人 (ひと) человек  
![04eba.svg](./downloaded/04eba.svg)  
10\. 儿 (にんにょう) ноги человека    
![0513f.svg](./downloaded/0513f.svg)  
11\. 入 (いる) входить  
![05165.svg](./downloaded/05165.svg)  
12\. 八 (はちがしら) восемь  
![0516b.svg](./downloaded/0516b.svg)  
13\. 冂 (まきがまえ) витрина, прилавок  
![05182.svg](./downloaded/05182.svg)  
14\. 冖 (わかんむり) корона  
![05196.svg](./downloaded/05196.svg)  
15\. 冫 (にすい) капли воды  
![051ab.svg](./downloaded/051ab.svg)  
16\. 几 (つくえ) стол  
![051e0.svg](./downloaded/051e0.svg)  
17\. 凵 (うけばこ) открытая коробка  
![051f5.svg](./downloaded/051f5.svg)  
18\. 刀 (かたな) меч  
![05200.svg](./downloaded/05200.svg)  
19\. 力 (ちから) сила  
![0529b.svg](./downloaded/0529b.svg)  
20\. 勹 (つつみがまえ) заворачивать, оборачивать  
![052f9.svg](./downloaded/052f9.svg)   
21\. 匕 (さじのひ) ложка  
![05315.svg](./downloaded/05315.svg)  
22\. 匚 (はこがまえ) коробка с открытой стенкой  
![0531a.svg](./downloaded/0531a.svg)  
23\. 匸 (かくしがまえ) прятать  
![05338.svg](./downloaded/05338.svg)  
24\. 十 (じゅう) крест  
![05341.svg](./downloaded/05341.svg)  
25\. 卜 (ぼくのと) волшебная палочка  
![0535c.svg](./downloaded/0535c.svg)  
26\. 卩 (ふしづくり) печать  
![05369.svg](./downloaded/05369.svg)  
27\. 厂 (がんだれ) утес  
![05382.svg](./downloaded/05382.svg)  
28\. 厶 (む) я   
![053b6.svg](./downloaded/053b6.svg)  
29\. 又 (また) кроме того, при этом  
![053c8.svg](./downloaded/053c8.svg)  
### 3 черты  

30\. 口(くち) рот    
![053e3.svg](./downloaded/053e3.svg)  
31\. 囗 (くにがまえ) коробка  
![056d7.svg](./downloaded/056d7.svg)  
32\. 土 (つち) земля, почва  
![0571f.svg](./downloaded/0571f.svg)  
33\. 士 (さむらい) самурай  
![058eb.svg](./downloaded/058eb.svg)  
34\. 夂 (ふゆがしら) зима, начинать  
![05902.svg](./downloaded/05902.svg)  
35\. 夊 (すい) волочить ноги  
![0590a.svg](./downloaded/0590a.svg)  
36\. 夕 (ゆうべ) вечер  
![05915.svg](./downloaded/05915.svg)  
37\. 大 (だい) большой  
![05927.svg](./downloaded/05927.svg)  
38\. 女 (おんな )женщина  
![05973.svg](./downloaded/05973.svg)  
39\. 子 (こ) ребенок  
![05b50.svg](./downloaded/05b50.svg)  
40\. 宀 (うかんむり) корона  
![05b80.svg](./downloaded/05b80.svg)  
41\. 寸 (すん) клей  
![05bf8.svg](./downloaded/05bf8.svg)  
42\. 小 (ちいさい) маленький  
![05c0f.svg](./downloaded/05c0f.svg)  
43\. 尢 (まげあし) изогнутый «большой»  
![05c22.svg](./downloaded/05c22.svg)  
44\. 尸 (しかばね) флаг  
![05c38.svg](./downloaded/05c38.svg)  
45\. 屮 (てつ) старая трава  
![05c6e.svg](./downloaded/05c6e.svg)  
46\. 山 (やま) гора  
![05c71.svg](./downloaded/05c71.svg)  
47\. 川 (まがりがわ) изогнутая «река»  
![05ddd.svg](./downloaded/05ddd.svg)  
48\. 工 (たくみ) навык, рабочий  
![05de5.svg](./downloaded/05de5.svg)  
49\. 己 (おのれ) змея  
![05df1.svg](./downloaded/05df1.svg)  
50\. 巾 (はば) одежда  
![05dfe.svg](./downloaded/05dfe.svg)  
51\. 干 (はす) сухой  
![05e72.svg](./downloaded/05e72.svg)  
52\. 幺 (いとがしら)короткая нитка  
![05e7a.svg](./downloaded/05e7a.svg)  
53\. 广 (まだれ) утес с точкой  
![05e7f.svg](./downloaded/05e7f.svg)  
54\. 廴 (いんにょう) широкий шаг  
![05ef4.svg](./downloaded/05ef4.svg)  
55\. 廾 (にじゅうあし) двадцать  
![05efe.svg](./downloaded/05efe.svg)  
56\. 弋 (しきがまえ) церемония  
![05f0b.svg](./downloaded/05f0b.svg)  
57\. 弓 (ゆみ) лук (оружие)  
![05f13.svg](./downloaded/05f13.svg)  
58\. ヨ (けいがしら) голова свиньи  
![030e8.svg](./downloaded/030e8.svg)  
59\. 彡 (さんづくり) пучок  
![05f61.svg](./downloaded/05f61.svg)  
60\. 彳 (ぎょうにんべん) идущий человек  
![05f73.svg](./downloaded/05f73.svg)  
### 4 черты  

61\. 心(りっしんべん) сердце   
![05fc3.svg](./downloaded/05fc3.svg)  
62\. 戈 (かのほこ) алебарда   
![06208.svg](./downloaded/06208.svg)  
63\. 戸 (とびらのと) дверь   
![06238.svg](./downloaded/06238.svg)  
64\. 手 (て) рука   
![0624b.svg](./downloaded/0624b.svg)  
65\. 支 (しんよう) ветка   
![0652f.svg](./downloaded/0652f.svg)  
66\. 攴 (ぼくづくり) складной стул   
![06534.svg](./downloaded/06534.svg)  
67\. 文 (ぶんにょう) предложение, фраза   
![06587.svg](./downloaded/06587.svg)  
68\. 斗 (とます) ковш, черпак   
![06597.svg](./downloaded/06597.svg)  
69\. 斤 (おの) топор   
![065a4.svg](./downloaded/065a4.svg)  
70\. 方 (ほう) сторона, направление   
![065b9.svg](./downloaded/065b9.svg)  
71\. 无 (むにょう) изогнутый «рай»   
![065e0.svg](./downloaded/065e0.svg)  
72\. 日 (にち) солнце   
![065e5.svg](./downloaded/065e5.svg)  
73\. 曰 (にち) плоское солнце   
![066f0.svg](./downloaded/066f0.svg)  
74\. 月 (つき) луна   
![06708.svg](./downloaded/06708.svg)  
75\. 木 (き) дерево   
![06728.svg](./downloaded/06728.svg)  
76\. 欠 (あくび) щель, пробел   
![06b20.svg](./downloaded/06b20.svg)  
77\. 止 (とめる) остановиться   
![06b62.svg](./downloaded/06b62.svg)  
78\. 歹 (がつへん) смерть   
![06b79.svg](./downloaded/06b79.svg)  
79\. 殳 (ほこつくり) снова ветрено   
![06bb3.svg](./downloaded/06bb3.svg)  
80\. 毋 (なかれ) мать   
![06bcb.svg](./downloaded/06bcb.svg)  
81\. 比 (くらべるひ) состязание в беге   
![06bd4.svg](./downloaded/06bd4.svg)  
82\. 毛 (け) шерсть   
![06bdb.svg](./downloaded/06bdb.svg)  
83\. 氏 (うじ) клан   
![06c0f.svg](./downloaded/06c0f.svg)  
84\. 气 (きがまえ) дух   
![06c14.svg](./downloaded/06c14.svg)  
85\. 水 (みず) вода   
![06c34.svg](./downloaded/06c34.svg)  
86\. 火 (ひ) огонь   
![0706b.svg](./downloaded/0706b.svg)  
87\. 爪 (つめ) коготь   
![0722a.svg](./downloaded/0722a.svg)  
88\. 父 (ちち) отец   
![07236.svg](./downloaded/07236.svg)  
89\. 爻 (めめ) двойной X   
![0723b.svg](./downloaded/0723b.svg)  
90\. 爿 (しょうへん) левосторонний «трафарет»   
![0723f.svg](./downloaded/0723f.svg)  
91\. 片 (かた) односторонний трафарет   
![07247.svg](./downloaded/07247.svg)  
92\. 牙 (きばへん) клык   
![07259.svg](./downloaded/07259.svg)  
93\. 牛 (うし) корова   
![0725b.svg](./downloaded/0725b.svg)  
94\. 犬 (いぬ) собака   
![072ac.svg](./downloaded/072ac.svg)  
96\. 王 (おう) король   
![0738b.svg](./downloaded/0738b.svg)  
### 5 черт  

95\. 玄(げん) таинственный  
![07384.svg](./downloaded/07384.svg)  
96\. 玉 (うし) драгоценность  
![07389.svg](./downloaded/07389.svg)  
97\. 瓜 (うり) арбуз  
![074dc.svg](./downloaded/074dc.svg)  
98\. 瓦 (かわら) черепица  
![074e6.svg](./downloaded/074e6.svg)  
99\. 甘 (あまい) сладкий  
![07518.svg](./downloaded/07518.svg)  
100\.生 (うまれる) жизнь  
![0751f.svg](./downloaded/0751f.svg)  
101\. 用 (もちいる) использовать  
![07528.svg](./downloaded/07528.svg)  
102\. 田 (た) рисовое поле  
![07530.svg](./downloaded/07530.svg)  
103\. 疋 (ひき) численность  
![0758b.svg](./downloaded/0758b.svg)  
104\. 疔 (やまいだれ) болезнь  
![07594.svg](./downloaded/07594.svg)  
105\. 癶 (はつがしら) «шатер» с точками  
![07676.svg](./downloaded/07676.svg)  
106\. 白 (しろ) белый  
![0767d.svg](./downloaded/0767d.svg)  
107\. 皮 (けがわ) прятаться  
![076ae.svg](./downloaded/076ae.svg)  
108\. 皿 (さら) тарелка  
![076bf.svg](./downloaded/076bf.svg)  
109\. 目 (め) глаз  
![076ee.svg](./downloaded/076ee.svg)  
110\. 矛 (むのほこ) алебарда  
![077db.svg](./downloaded/077db.svg)  
111\. 矢 (や) стрела  
![077e2.svg](./downloaded/077e2.svg)  
112\. 石 (いし) камень  
![077f3.svg](./downloaded/077f3.svg)  
113\. 示 (しめす) показывать, указывать  
![0793a.svg](./downloaded/0793a.svg)  
114\. 禹 (うのあし) МУ в коробке  
![079b9.svg](./downloaded/079b9.svg)  
115\. 禾 (のぎ) дерево с двумя ветками  
![079be.svg](./downloaded/079be.svg)  
116\. 穴 (あな) щель, разрез  
![07a74.svg](./downloaded/07a74.svg)  
117\. 立 (たつ) стоять  
![07acb.svg](./downloaded/07acb.svg)  
### 6 черт  

118\. 竹(たけ) бамбук  
![07af9.svg](./downloaded/07af9.svg)  
119\. 米 (こめ) рис  
![07c73.svg](./downloaded/07c73.svg)  
120\. 糸 (いと) нитка  
![07cf8.svg](./downloaded/07cf8.svg)  
121\. 缶 (ほとぎ) бидон, лейка  
![07f36.svg](./downloaded/07f36.svg)  
122\. 网 (あみがしら) сеть  
![07f51.svg](./downloaded/07f51.svg)  
123\. 羊 (ひつじ) овца  
![07f8a.svg](./downloaded/07f8a.svg)  
124\. 羽 (はね) перья  
![07fbd.svg](./downloaded/07fbd.svg)  
125\. 老 (おい) пожилой человек  
![08001.svg](./downloaded/08001.svg)  
126\. 而 (しかして) грабли  
![0800c.svg](./downloaded/0800c.svg)  
127\. 耒 (らいすき) дерево с тремя ветками  
![08012.svg](./downloaded/08012.svg)  
128\. 耳 (みみ ) ухо  
![08033.svg](./downloaded/08033.svg)  
129\. 聿 (ふでづくり) кисть для письма  
![0807f.svg](./downloaded/0807f.svg)  
130\. 肉 (にく) мясо  
![08089.svg](./downloaded/08089.svg)  
131\. 臣 (しん) вассал  
![081e3.svg](./downloaded/081e3.svg)  
132\. 自 (みずから) себя  
![081ea.svg](./downloaded/081ea.svg)  
133\. 至 (いたる) высшая точка, кульминация  
![081f3.svg](./downloaded/081f3.svg)  
134\. 臼 (うす) мортира  
![081fc.svg](./downloaded/081fc.svg)  
135\. 舌 (した) язык  
![0820c.svg](./downloaded/0820c.svg)  
136\. 舛 (ます) танцевать  
![0821b.svg](./downloaded/0821b.svg)  
137\. 舟 (ふね) корабль  
![0821f.svg](./downloaded/0821f.svg)  
138\. 艮 (うしとら) хороший  
![0826e.svg](./downloaded/0826e.svg)  
139\. 色 (いろ) цвет  
![08272.svg](./downloaded/08272.svg)  
140\. 艸 (くさ) трава  
![08278.svg](./downloaded/08278.svg)  
141\. 虍 (とらかんむり) тигр  
![0864d.svg](./downloaded/0864d.svg)  
142\. 虫 (むし) насекомое  
![0866b.svg](./downloaded/0866b.svg)  
143\. 血 (ち) кровь  
![08840.svg](./downloaded/08840.svg)  
144\. 行 (ぎょう) идти  
![0884c.svg](./downloaded/0884c.svg)  
145\. 衣 (ころも) одежда  
![08863.svg](./downloaded/08863.svg)  
146\. 襾 (にし) запад  
![0897e.svg](./downloaded/0897e.svg)  
### 7 черт  

147\. 見(みる) видеть  
![0898b.svg](./downloaded/0898b.svg)  
148\. 角 (つの) угол, рог  
![089d2.svg](./downloaded/089d2.svg)  
149\. 言 (ことば) говорить  
![08a00.svg](./downloaded/08a00.svg)  
150\. 谷 (たに) долина  
![08c37.svg](./downloaded/08c37.svg)  
151\. 豆 (まめ) боб  
![08c46.svg](./downloaded/08c46.svg)  
152\. 豕 (いのこ) свинья  
![08c55.svg](./downloaded/08c55.svg)  
153\. 豸 (むじな) барсук  
![08c78.svg](./downloaded/08c78.svg)  
154\. 貝 (かい) морская раковина  
![08c9d.svg](./downloaded/08c9d.svg)  
155\. 赤 (あか) красный  
![08d64.svg](./downloaded/08d64.svg)  
156\. 走 (はしる) бежать  
![08d70.svg](./downloaded/08d70.svg)  
157\. 足 (あし) нога  
![08db3.svg](./downloaded/08db3.svg)  
158\. 身 (み) тело  
![08eab.svg](./downloaded/08eab.svg)  
159\. 車 (くるま) колесо  
![08eca.svg](./downloaded/08eca.svg)  
160\. 辛 (からい) пряный  
![08f9b.svg](./downloaded/08f9b.svg)  
161\. 辰 (しんのたつ) дракон  
![08fb0.svg](./downloaded/08fb0.svg)  
162\. 辷 (しんにゅう) дорога  
![08fb7.svg](./downloaded/08fb7.svg)  
163\. 邑 (むら) деревня  
![09091.svg](./downloaded/09091.svg)  
164\. 酉 (ひよみのとり) сакэ  
![09149.svg](./downloaded/09149.svg)  
165\. 釆 (のごめ) игральные кости  
![091c6.svg](./downloaded/091c6.svg)  
166\. 里 (さと) деревня  
![091cc.svg](./downloaded/091cc.svg)  
### 8 черт  

167\. 金(かね) металл  
![091d1.svg](./downloaded/091d1.svg)  
168\. 長 (ながい) длинный  
![09577.svg](./downloaded/09577.svg)  
169\. 門 (もん) ворота  
![09580.svg](./downloaded/09580.svg)  
170\. 阜 (ぎふのふ) деревня  
![0961c.svg](./downloaded/0961c.svg)  
171\. 隶 (れいづくり) раб  
![096b6.svg](./downloaded/096b6.svg)  
172\. 隹 (ふるとり) старая птица  
![096b9.svg](./downloaded/096b9.svg)  
173\. 雨 (あめ) дождь  
![096e8.svg](./downloaded/096e8.svg)  
174\. 青 (あう) зеленый, синий  
![09752.svg](./downloaded/09752.svg)  
175\. 非 (あらず) несправедливость  
![0975e.svg](./downloaded/0975e.svg)  
### 9 черт  

176\. 面(めん) поверхность   
![09762.svg](./downloaded/09762.svg)  
177\. 革 (かくのかわ) кожа   
![09769.svg](./downloaded/09769.svg)  
178\. 韋 (なめしがわ) обожженная кожа 
![097cb.svg](./downloaded/097cb.svg)    
179\. 韭 (にら) лук-порей   
![097ed.svg](./downloaded/097ed.svg)  
180\. 音 (おと) звук   
![097f3.svg](./downloaded/097f3.svg)  
181\. 頁 (おおがい) голова   
![09801.svg](./downloaded/09801.svg)  
182\. 風 (かぜ) ветер   
![098a8.svg](./downloaded/098a8.svg)  
183\. 飛 (とぶ) летать   
![098db.svg](./downloaded/098db.svg)  
184\. 食 (しよく) еда   
![098df.svg](./downloaded/098df.svg)  
185\. 首 (くび) шея   
![09996.svg](./downloaded/09996.svg)  
186\. 香 (においこう) запах   
![09999.svg](./downloaded/09999.svg)  
### 10 черт  

187\. 馬(うま) лошадь  
![099ac.svg](./downloaded/099ac.svg)  
188\. 骨 (ほね) кость  
![09aa8.svg](./downloaded/09aa8.svg)  
189\. 高 (たかい) высокий  
![09ad8.svg](./downloaded/09ad8.svg)  
190\. 髟 (かみがしら) длинные волосы  
![09adf.svg](./downloaded/09adf.svg)  
191\. 鬥 (とうがまえ) сломанные ворота 
![09b25.svg](./downloaded/09b25.svg)   
192\. 鬯 (ちよう) ароматные травы  
![09b2f.svg](./downloaded/09b2f.svg)  
193\. 鬲 (かく) тренога  
![09b32.svg](./downloaded/09b32.svg)  
194\. 鬼 (おに) демон  
![09b3c.svg](./downloaded/09b3c.svg)  
### 11 черт  

195\. 魚(うお) рыба  
![09b5a.svg](./downloaded/09b5a.svg)  
196\. 鳥 (とり) птица  
![09ce5.svg](./downloaded/09ce5.svg)  
197\. 鹵 (ろ) соль  
![09e75.svg](./downloaded/09e75.svg)  
198\. 鹿 (しか) олень  
![09e7f.svg](./downloaded/09e7f.svg)  
199\. 麥 (むぎ) пшеница  
![09ea5.svg](./downloaded/09ea5.svg)   
200\. 麻 (あさ) лен  
![09ebb.svg](./downloaded/09ebb.svg)  
### 13 черт  

201\. 黄(きいろ) желтый  
![09ec4.svg](./downloaded/09ec4.svg)  
202\. 黍 (きび) просо  
![09ecd.svg](./downloaded/09ecd.svg)  
203\. 黒 (くろ) черный  
![09ed2.svg](./downloaded/09ed2.svg)  
204\. 黹 (ふつ) шить  
![09ef9.svg](./downloaded/09ef9.svg)  
205\. 黽 (べん) зеленая лягушка  
![09efd.svg](./downloaded/09efd.svg)  
206\. 鼎 (かなえ) чайник на трех ножках  
![09f0e.svg](./downloaded/09f0e.svg)  
207\. 鼓 (つづみ) барабанный бой  
![09f13.svg](./downloaded/09f13.svg)  
208\. 鼠 (ねずみ) мышь  
![09f20.svg](./downloaded/09f20.svg)  
### 14 черт  

209\. 鼻(はな) нос  
![09f3b.svg](./downloaded/09f3b.svg)  
210\. 齊 (せい) равный  
![09f4a.svg](./downloaded/09f4a.svg)  
### 15 черт  

211\. 齒(は )зуб  
![09f52.svg](./downloaded/09f52.svg)  
### 16 черт  

212\. 龍(りゅう) дракон  
![09f8d.svg](./downloaded/09f8d.svg)  
213\. 龜 (かめ) черепаха  
![09f9c.svg](./downloaded/09f9c.svg)  
### 17 черт  

214\. 龠(やく) флейта  
![09fa0.svg](./downloaded/09fa0.svg)  
  